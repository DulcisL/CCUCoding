

class Search():


    def linearsearch(self, searchList, n, x):
        for i in range(0, n):
            if (searchList[i] == x):
                return i
        return -1

    def BinarySearch(self,searchList, low, high, key):  #user-defined function
        if high >= low:  #check base case
            mid = (high + low) // 2
            if (searchList[mid] == key):
                return mid
            elif (searchList[mid] > key):
                return self.BinarySearch(searchList, low, mid - 1, key)
            else:
                return self.BinarySearch(searchList, mid + 1, high, key)
        else:
            return -1