function P = principalComponents(X, q)
%principalComponents - Principal components of a vector population.
% P = principalComponents(X, q) computes the principal-component
% vectors of the vector population contained in the rows of X, a matrix of
% size K-by-n where K (assumed to be > 1) is the number of vectors and n
% is their dimensionality. q, with values in the range [0,n], is the
% number of eigenvectors used in constructing the principal-components
% transformation matrix. P is a structure with the following fields:
%
% P.Y   K-by-q matrix whose rows are the principal-component vectors.
% P.A   q-by-n principal components transformation matrix whose rows are
%       the q eigenvectors of Cx corresponding to the q largest eigenvalues.
% P.X   K-by-n matrix whose rows are the vectors reconstructed from P.Y.
%       P.X and X are identical if q = n.
% P.ems The mean square error incurred in using only the q eigenvectors
%       corresponding to the largest eigenvalues. P.ems is 0 if q = n.
% P.Cx  The n-by-n covariance matrix of the population in X.
% P.mx  The n-by-1 mean vector of the population in X.
% P.Cy  The q-by-q covariance matrix of the population in Y. The main
%       diagonal contains the eigenvalues (in descending order).

K = size(X, 1);      % Number of vectors
X = double(X);       % Ensure data is in double format

% Obtain the mean vector and covariance matrix of the vectors in X
[P.Cx, P.mx] = covmatrix(X);

% Convert mean vector to a row vector
P.mx = P.mx';

% Obtain the eigenvectors and corresponding eigenvalues of Cx.
% The eigenvectors are the columns of matrix V.
% D is diagonal with corresponding eigenvalues.
[V, D] = eig(P.Cx);

% Sort eigenvalues in decreasing order and rearrange eigenvectors
d = diag(D);
[d, idx] = sort(d, 'descend');
D = diag(d);
V = V(:, idx);

% Form the transformation matrix A from the first q eigenvectors
P.A = V(:, 1:q)';

% Compute the principal component vectors (size: q-by-K)
P.Y = P.A * (X - P.mx)';   % subtract mean from each row

% Reconstruct the vectors from the principal components
P.X = (P.A' * P.Y)' + P.mx;

% Convert P.Y to K-by-q and P.mx to n-by-1
P.Y = P.Y';
P.mx = P.mx';

% Mean square error from using only q eigenvectors
P.ems = sum(d(q+1:end));

% Covariance matrix of Y
P.Cy = P.A * P.Cx * P.A';
