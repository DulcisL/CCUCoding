function [g1,g2,g3] = Exercise4a(f,K,N)
%Create a function to apply the kmeans and superpixel segmentation to the
%images from the slides and notes. 
%   g1 - segement f into k clusters using the kmeans algorithm
%   g2 - create the superpixel image of f with N desired superpixels
%   g3 - segment g2 into k clusters using the kmeans clustering algorithm

[m,n,c] = size(f);
f = im2double(f);
if c > 1
    tar = 3; %targetted color if RGB
else
    tar = 1;
end

%Work on g1 and kmeans clustering
%reshape into a single row/column matrix for kmeans by RGB color
X = reshape(f, [m*n, c]);
%Choose which layer of color you would like to use
[IDX, C] = kmeans(X(:,tar), K); %returns cluster indices (IDX) -> vector, Cluster centroid locations(C) -> matrix
%apply the cluster
g1 = reshape(C(IDX), [m,n]);

%Create image with N super pixels
[L, numlab] = superpixels(f, N); %returns label matrix(L) -> int, number of labels (numlab) -> int

%Show boundaries of superpixels
BW = boundarymask(L);
g2 = zeros(size(f), "like", f);
overlay = imoverlay(f,BW,'red');

%Apply superpixels
idx = label2idx(L);

if c > 1 %if RGB
    for labelVal = 1:numlab
        redIdx = idx{labelVal};
        greenIdx = idx{labelVal}+m*n;
        blueIdx = idx{labelVal}+2*m*n;
        g2(redIdx) = mean(f(redIdx));
        g2(greenIdx) = mean(f(greenIdx));
        g2(blueIdx) = mean(f(blueIdx));
    end
else %if a grayscale
    for labelVal = 1:numlab
        grayIdx = idx{labelVal};
        g2(grayIdx) = mean(f(grayIdx));
    end
end

%Apply both to image
[m,n,c] = size(g2);
X = reshape(g2, [m*n,c]);
[IDX, C] = kmeans(X(:,tar), K);
g3 = reshape(C(IDX), [m,n]);
end