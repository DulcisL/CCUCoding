#working with files
#why write to files
#no database requried
#the ability to save data when program has ended
#the ability to restore data when program is started

#create a text file
#create a file object variable
#open takes a file path
#R - Read
#W = Write
#O - Overwrites the file
#Ab - Appends to begining
#Ae - Appends to end
#E - Generates errors
#mode r - RE
#mode r+ - RWAe
#mode w+ - RWAb
#mode a - WAeE
#mode w - WOAb

#+f causes an error FileNotFoundError
#catch the error and create the file if error occured
#Import the file with the class

#exceptions - a process to control errors that may happen in your program
#in programmin this is how you esimate and handel error to keep your program from crashing.

#ask user to enter numbers (enter any character to stop)

#Get an items from a list at index 5 and index 7
#catch any errors